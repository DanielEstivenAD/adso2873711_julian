
document.getElementById('ideas').addEventListener('click', function() {
    var contenedor4 = document.getElementById('contenedor4');
    if (contenedor4.style.display === 'none' || contenedor4.style.display === '') {
        contenedor4.style.display = 'block';
    } else {
        contenedor4.style.display = 'none'; 
    }
});

document.querySelectorAll('.section-header').forEach(header => {
    header.addEventListener('click', () => {
        const content = header.nextElementSibling;
        content.style.display = content.style.display === 'none' ? 'block' : 'none';
    });
});

document.getElementById('contenedor4').style.display = 'none';

function validateLogin() {
    const validUsername = 'usuario';
    const validPassword = 'contraseña123';

    const username = document.getElementById('usuario').value;
    const password = document.getElementById('contraseña').value;
    const tipoUsuario = document.getElementById('tipoUsuario').value;
    const errorMessage = document.getElementById('mensaje-de-error');

    if (tipoUsuario === '') {
        errorMessage.textContent = 'Por favor, selecciona un tipo de usuario.';
        return;
    }

    if (username === validUsername && password === validPassword) {
        errorMessage.textContent = '';
        // Aquí puedes redirigir al usuario a otra página, por ejemplo:
        window.location.href = 'index.html';
    } else {
        errorMessage.textContent = 'Nombre de usuario o contraseña incorrectos.';
    }
}